package chapter13;
/**
 * @author Arshdeep Kapoor
 * 
 */
public interface Colorable {
	String howToColor();
}
